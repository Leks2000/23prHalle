﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Пр23_Халле
{
    public partial class Main : Form
    {
        private Users users;
        private Tovar tablproduct;
        public Main()
        {
            InitializeComponent();
        }

        private void покупателиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            users = new Users();
            users.Visible = true; 
        }

        private void товарыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tablproduct = new Tovar();
            tablproduct.Visible = true;
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void выходToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
