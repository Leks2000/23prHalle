﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Пр23_Халле
{
    public partial class TableTovars : Form
    {
        public TableTovars()
        {
            InitializeComponent();
            System.Windows.Forms.ToolTip tip = new System.Windows.Forms.ToolTip();
            tip.SetToolTip(comboBox1,"введите наименование товара");
            tip.SetToolTip(textBox1,"введите пояснение к товару");

        }
        
        private void productsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();

        }

        private void Tovars_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pK_ShopDataSet.Products". При необходимости она может быть перемещена или удалена.
            this.productsTableAdapter.Fill(this.pK_ShopDataSet.Products);

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnsort.Enabled = true;
        }

        private System.Windows.Forms.DataGridViewColumn COL;
        private void btnsort_Click(object sender, EventArgs e)
        {
            COL = new System.Windows.Forms.DataGridViewColumn();
            switch (listBox1.SelectedIndex)
            {
                case 0:
                    COL = nameDataGridViewTextBoxColumn;
                    break;
                case 1:
                    COL = priceDataGridViewTextBoxColumn;
                    break;
                case 2:
                    COL = countDataGridViewTextBoxColumn;
                    break;
                case 3:
                    COL = markDataGridViewTextBoxColumn;
                    break;
                case 4:
                    COL = descriptionDataGridViewTextBoxColumn;
                    break;
            }
            if (radioButton1.Checked)
                dataGridViewProduct.Sort(COL, System.ComponentModel.ListSortDirection.Ascending);
            else
                dataGridViewProduct.Sort(COL, System.ComponentModel.ListSortDirection.Descending);
        }

        private void btnfilrt_Click(object sender, EventArgs e)
        {
            bindingSourceTablProd.Filter = "Name='" + comboBox1.Text + "'";
        }

        private void btnopenall_Click(object sender, EventArgs e)
        {
            bindingSourceTablProd.Filter = "";
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridViewProduct.ColumnCount - 1; i++)
            {
                for (int j = 0; j < dataGridViewProduct.RowCount - 1; j++)
                {
                    dataGridViewProduct[i, j].Style.BackColor = Color.White;
                    dataGridViewProduct[i, j].Style.ForeColor = Color.Black;
                }

            }
            for (int i = 0; i < dataGridViewProduct.ColumnCount - 1; i++)
            {
                for (int j = 0; j < dataGridViewProduct.RowCount - 1; j++)
                {
                    if (dataGridViewProduct[i,j].Value.ToString().IndexOf(textBox1.Text) != -1)
                    {
                    dataGridViewProduct[i, j].Style.BackColor = Color.AliceBlue;
                    dataGridViewProduct[i, j].Style.ForeColor = Color.Blue;
                    }
                }

            }
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void statusStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void comboBox1_MouseEnter(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Выберите наименование товара для фильтрации";
        }

        private void textBox1_MouseEnter(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = "Выберите цену товара для фильтрации";
        }
    }
}
