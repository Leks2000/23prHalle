﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Пр23_Халле
{
    public partial class Tovar : Form
    {
        private TableTovars tablprod;
        public Tovar()
        {
            InitializeComponent();
        }

        private void productsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.usersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.pK_ShopDataSet);

        }

        private void Tovars_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pK_ShopDataSet.Products". При необходимости она может быть перемещена или удалена.
            this.productsTableAdapter.Fill(this.pK_ShopDataSet.Products);

        }

        private void ButtonAddProp_Click(object sender, EventArgs e)
        {
            usersBindingSource.AddNew();
        }

        private void ButtDel_Click(object sender, EventArgs e)
        {
            usersBindingSource.RemoveCurrent();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.usersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.pK_ShopDataSet);
        }

        private void BtnSearchForCode_Click(object sender, EventArgs e)
        {
            string sql = String.Concat("SELECT * FROM Products WHERE IdProducts=", idProducts.Text);
            string connectionString;
            connectionString = @"Data source =(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\ПР23_ХАЛЛЕ\ПР23_ХАЛЛЕ\BIN\DEBUG\PK_SHOP.MDF;Integrated Security=True";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = new SqlCommand(sql, connection);
            SqlDataReader dataReader= command.ExecuteReader();
            nametxtbox.Text = "";
            maskedTextBox1.Text = "";
            counttxtbox.Text = "";
            maskedTextBox2.Text = "";
            descripttxtbox.Text = "";
            while (dataReader.Read())
            {
                nametxtbox.Text = nametxtbox.Text + dataReader["Name"];
                maskedTextBox1.Text = maskedTextBox1.Text + dataReader["Price"];
                counttxtbox.Text = counttxtbox.Text + dataReader["Count"];
                maskedTextBox2.Text = maskedTextBox2.Text + dataReader["Mark"];
                descripttxtbox.Text = descripttxtbox.Text + dataReader["Description"];
            }
            dataReader.Close();
            connection.Close();

        }


        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            tablprod = new TableTovars();
            tablprod.Visible = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            nametxtbox.Text = "";
            maskedTextBox1.Text = "";
            counttxtbox.Text = "";
            maskedTextBox2.Text = "";
            descripttxtbox.Text = "";
        }
    }
}
